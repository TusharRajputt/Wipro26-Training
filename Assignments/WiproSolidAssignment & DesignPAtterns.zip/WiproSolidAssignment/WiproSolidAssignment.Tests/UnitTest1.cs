using NUnit.Framework;
using WiproSolidAssignment.Patterns;

namespace WiproSolidAssignment.Tests
{
    public class LoggerTests
    {
        [Test]
        public void Singleton_Should_Return_Same_Instance()
        {
            var logger1 = Logger.Instance;
            var logger2 = Logger.Instance;

            Assert.That(logger1, Is.SameAs(logger2));
        }
    }
}