﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NUnit.Framework;
using WiproSolidAssignment.Services;
using WiproSolidAssignment.Models;

namespace WiproSolidAssignment.Tests
{
    public class ReportTests
    {
        [Test]
        public void Generator_Should_Create_Report_With_Correct_Data()
        {
            var generator = new ReportGenerator();

            var report = generator.Generate("Title", "Content");

            Assert.That(report.Title, Is.EqualTo("Title"));
            Assert.That(report.Content, Is.EqualTo("Content"));
        }
    }
}