﻿using NUnit.Framework;
using WiproSolidAssignment.Services;
using WiproSolidAssignment.Formatters;

namespace WiproSolidAssignment.Tests
{
    public class FormatterTests
    {
        [Test]
        public void PdfFormatter_Should_Format_Content()
        {
            var formatter = new ReportFormatter(new PdfFormatter());

            var result = formatter.Format("Hello");

            Assert.That(result, Does.Contain("PDF"));
        }
    }
}