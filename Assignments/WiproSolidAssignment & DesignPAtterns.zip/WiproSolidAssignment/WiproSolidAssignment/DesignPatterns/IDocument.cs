﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproSolidAssignment.DesignPatterns
{
    public interface IDocument
    {
        void Open();
    }
}