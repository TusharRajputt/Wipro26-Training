﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;

namespace WiproSolidAssignment.Patterns
{
    public sealed class Logger
    {
        private static Logger _instance;
        private static readonly object _lock = new object();

        private Logger() { }

        public static Logger Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                        _instance = new Logger();

                    return _instance;
                }
            }
        }

        public void Log(string message)
        {
            Console.WriteLine("LOG: " + message);
        }
    }
}