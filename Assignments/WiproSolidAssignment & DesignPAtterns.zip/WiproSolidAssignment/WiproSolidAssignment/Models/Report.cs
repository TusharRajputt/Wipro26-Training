﻿namespace WiproSolidAssignment.Models
{
    public class Report
    {
        public string Title { get; set; }
        public string Content { get; set; }

        public virtual string GetContent()
        {
            return $"{Title}\n{Content}";
        }
    }
}