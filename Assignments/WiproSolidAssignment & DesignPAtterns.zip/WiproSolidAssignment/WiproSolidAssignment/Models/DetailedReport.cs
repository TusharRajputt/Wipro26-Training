﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproSolidAssignment.Models
{
    public class DetailedReport : Report
    {
        public override string GetContent()
        {
            return "[Detailed]\n" + base.GetContent();
        }
    }
}