﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WiproSolidAssignment.DesignPatterns;
using WiproSolidAssignment.Services;
using WiproSolidAssignment.Patterns;
using WiproSolidAssignment.Formatters;

namespace WiproSolidAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            var generator = new ReportGenerator();
            var saver = new ReportSaver();

            var service = new ReportService(generator, saver);
            service.CreateReport("Sales Report", "Revenue 10K");

            var formatter = new ReportFormatter(new PdfFormatter());
            Console.WriteLine(formatter.Format("Hello Report"));

            var logger = Logger.Instance;
            logger.Log("Application started");
            // ===== Factory Pattern Demo =====
            var pdfDoc = DocumentFactory.CreateDocument("pdf");
            pdfDoc.Open();

            var wordDoc = DocumentFactory.CreateDocument("word");
            wordDoc.Open();

            Console.ReadKey();
        }
    }
}