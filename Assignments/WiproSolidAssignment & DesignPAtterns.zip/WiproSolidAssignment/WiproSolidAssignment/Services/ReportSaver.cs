﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WiproSolidAssignment.Interfaces;
using WiproSolidAssignment.Models;

namespace WiproSolidAssignment.Services
{
    public class ReportSaver : IReportSaver
    {
        public void SaveToFile(Report report, string path)
        {
            File.WriteAllText(path, report.GetContent());
        }
    }
}