﻿using WiproSolidAssignment.Interfaces;

namespace WiproSolidAssignment.Services
{
    public class ReportService
    {
        private readonly IReportGenerator _generator;
        private readonly IReportSaver _saver;

        public ReportService(IReportGenerator generator, IReportSaver saver)
        {
            _generator = generator;
            _saver = saver;
        }

        public void CreateReport(string title, string content)
        {
            var report = _generator.Generate(title, content);
            _saver.SaveToFile(report, "report.txt");
        }
    }
}