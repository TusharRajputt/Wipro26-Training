﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WiproSolidAssignment.Interfaces;
using WiproSolidAssignment.Models;

namespace WiproSolidAssignment.Services
{
    public class ReportGenerator : IReportGenerator
    {
        public Report Generate(string title, string content)
        {
            return new Report
            {
                Title = title,
                Content = content
            };
        }
    }
}
