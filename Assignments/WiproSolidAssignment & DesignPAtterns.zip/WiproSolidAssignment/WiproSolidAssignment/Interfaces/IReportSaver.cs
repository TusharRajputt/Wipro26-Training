﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using WiproSolidAssignment.Models;

namespace WiproSolidAssignment.Interfaces
{
    public interface IReportSaver
    {
        void SaveToFile(Report report, string path);
    }
}