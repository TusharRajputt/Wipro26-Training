﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using WiproSolidAssignment.Models;

namespace WiproSolidAssignment.Interfaces
{
    public interface IReportGenerator
    {
        Report Generate(string title, string content);
    }
}
