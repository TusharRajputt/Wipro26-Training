﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WiproSolidAssignment.Interfaces
{
    public interface IReportWriter
    {
        void Write(string content);
    }
}