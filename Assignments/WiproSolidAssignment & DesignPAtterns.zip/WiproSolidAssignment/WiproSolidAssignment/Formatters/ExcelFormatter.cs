﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using WiproSolidAssignment.Interfaces;

namespace WiproSolidAssignment.Formatters
{
    public class ExcelFormatter : IReportFormatter
    {
        public string Format(string content)
        {
            return "[EXCEL]\n" + content;
        }
    }
}